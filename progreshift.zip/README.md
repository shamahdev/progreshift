# Progreshift
Website for Himasi Website Design Competition 2020 (Hiedescom)

## Team / Contributor
We're from SMK Negeri 1 Cimahi
* Candra Miftah
* [Muhammad Rifki Erlangga](https://github.com/RifkiEr24)
* [Shaddam Amru Hasibuan](https://github.com/Shaddamah)

## License
[MIT](https://choosealicense.com/licenses/mit/)
